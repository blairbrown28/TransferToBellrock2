# -*- coding: utf-8 -*-
"""
Created on Tue Jan 26 17:58:56 2021

@author: wkb07111
"""

from __future__ import print_function
import Simple_Sum_Function_250121_PKG
import matlab

my_Simple_Sum_Function_250121_PKG = Simple_Sum_Function_250121_PKG.initialize()

my_Simple_Sum_Function_250121_PKG.terminate()