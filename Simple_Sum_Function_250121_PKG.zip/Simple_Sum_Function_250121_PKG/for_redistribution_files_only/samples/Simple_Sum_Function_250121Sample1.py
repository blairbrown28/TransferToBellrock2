#!/usr/bin/env python
"""
Sample script that uses the Simple_Sum_Function_250121_PKG module created using
MATLAB Compiler SDK.

Refer to the MATLAB Compiler SDK documentation for more information.
"""

from __future__ import print_function
import Simple_Sum_Function_250121_PKG
import matlab

my_Simple_Sum_Function_250121_PKG = Simple_Sum_Function_250121_PKG.initialize()

inputArg1In = matlab.double([0.0], size=(1, 1))
inputArg2In = matlab.double([0.0], size=(1, 1))
outputArg1Out = my_Simple_Sum_Function_250121_PKG.Simple_Sum_Function_250121(inputArg1In, inputArg2In)
print(outputArg1Out, sep='\n')

my_Simple_Sum_Function_250121_PKG.terminate()
