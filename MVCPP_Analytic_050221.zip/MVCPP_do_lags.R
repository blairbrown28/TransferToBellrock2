MVCPP_do_lags<- function(dat, col.name, num.lags) {
  for (i in 1:num.lags) {
    dat[[paste0(col.name, '.Lag', i)]] = lag(dat[[col.name]],i)
  }
  
  return(dat)
}