#!/usr/bin/Rscript
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#


# # set a path to the project folder. Assume there are subfolders: code, data, models, output, predictions
#setwd(getSrcDirectory()[1])
setwd("/opt/lumen/executable/")

#Add required support files for saving results and exceptions to redis
source("writeToRedis.R",chdir=T)
source("writeExceptionToRedis.R",chdir=T)
source("PreprocessAndCheck.R",chdir=T)
source("MVCPP_do_lags.R",chdir=T)

result<-tryCatch({
  #Specify required libraries for the analytic
  require(jsonlite)
  require(rredis)
  
  require(dplyr)
  require(lubridate)
  require(mgcv)
  require(kernlab)
  
  require(rlist)
  require(tidyr)
  require(stringr)
  
  #source("RogersEncodeRatios.R",chdir=T)
  
  #source("MVCPP_Training_and_Calibration.R",chdir=T)
  
  ######################
  # Functions
  #######################
  
  # #########################################
  # #Prune the outliers for a specific columns
  # prune.outliers <- function(tab, col){
  #   Q <- quantile(col, probs=c(.25, .75), na.rm = TRUE)
  #   iqr <- IQR(col)
  #   eliminated<- subset(tab, col > (Q[1] - 1.5*iqr) & col < (Q[2]+1.5*iqr))
  #   return(eliminated)
  # } 
  # ########################################
  
  # ########################################
  # #Prune all the columns
  # clean.vib.cols <- function() {
  #   vib.cols <- grep("^Ch.*Vib$", colnames(rul.data), value=TRUE)
  #   eliminated <- rul.data
  #   
  #   for (col in vib.cols) {
  #     eliminated<- prune.outliers(eliminated, eliminated[[col]])
  #   }
  #   
  #   return(eliminated)
  # }
  #######################################
  
  # #######################################
  # #introduce lag columns to help fitting
  # do.lags<- function(dat, col.name, num.lags) {
  #   for (i in 1:num.lags) {
  #     dat[[paste0(col.name, '.Lag', i)]] = lag(dat[[col.name]],i)
  #   }
  #   
  #   return(dat)
  # }
  # #######################################
  
  # ########################################
  # #this is a custom piece of code to specify the models 
  # #i don't really have time to optimise this, and iit really should be, 
  # #but good for a proof of concept.
  # train.model<- function(training.data){
  #   gam_classifier1 <- gam(Ch1RMSVib ~  HMMState+s(Speed) + s(Ch1RMSVib.Lag1)+s(Ch1RMSVib.Lag2) + s(Ch1RMSVib.Lag3), data=training.data)
  #   gam_classifier2 <- gam(Ch2RMSVib ~  HMMState+s(Speed) + Ch2RMSVib.Lag1 +Ch2RMSVib.Lag2 + Ch2RMSVib.Lag3, data=training.data)
  #   gam_classifier3 <- gam(Ch3RMSVib ~  HMMState+s(Speed) + s(Ch3RMSVib.Lag1)+s(Ch3RMSVib.Lag2) +  s(Ch3RMSVib.Lag3), data=training.data)
  #   gam_classifier4 <- gam(Ch4RMSVib ~  HMMState+s(Speed) + s(Ch4RMSVib.Lag1)+s(Ch4RMSVib.Lag2) +  s(Ch4RMSVib.Lag3), data=training.data)
  #   
  #   return(list(gam_classifier1,gam_classifier2,gam_classifier3,gam_classifier4))
  # }
  # #######################################
  
  # #######################################
  # #Compute non-conformity along a single dimension (1-4)
  # do.calibration.one.dim <- function(calibration.data, trained.models, kernel, d, subsample=1000) {
  #   
  #   #apply the models and calculate the residuals
  #   calibration.residuals <-calibration.data[[paste0('Ch',d,'RMSVib')]]-predict(trained.models[[d]], calibration.data)
  #   calibration.residuals = as.matrix(calibration.residuals)
  #   
  #   #compute the non-conformity measure later used for testing extremity
  #   non.conformity.measure <- rep(0, nrow(calibration.residuals))
  #   for (i in 1:nrow(calibration.residuals)){
  #     X = as.matrix(calibration.residuals[-c(i),])
  #     #  X = X[sample(nrow(X), subsample), ]
  #     
  #     Y = t(as.matrix(calibration.residuals[i,],nrow=1))
  #     
  #     KXX = kernelMatrix(kernel, X,X)
  #     KXY = kernelMatrix(kernel, X, Y)
  #     KYY = kernelMatrix(kernel,Y,Y)
  #     non.conformity.measure[i] =   mean(KXX) - 2*mean(KXY) + mean(KYY) 
  #   }
  #   return(non.conformity.measure)
  # }
  # #################################################
  
  # #################################################
  # #Compute non-conformity measures along the entire set of dimensions
  # do.calibration <- function(calibration.data, trained.models, kernel, subsample=1000) {
  #   
  #   #apply the models and calculate the residuals
  #   calibration.residuals <- do.call(rbind, lapply(1:4, FUN=function(i) calibration.data[[paste0('Ch',i,'RMSVib')]]-predict(trained.models[[i]], calibration.data)))
  #   calibration.residuals = t(calibration.residuals)
  #   
  #   #removce some initial NAs due to lags
  #   calibration.residuals <- calibration.residuals[-c(1:4),]
  #   
  #   print("Starting calibration loop")
  #   #compute the non-conformity measure later used for testing extremity
  #   non.conformity.measure <- rep(0, nrow(calibration.residuals))
  #   for (i in 1:nrow(calibration.residuals)){
  #     X = as.matrix(calibration.residuals[-c(i),])
  #     
  #     #introduce subsampling
  #     #   X = X[sample(nrow(X), subsample), ]
  #     Y = t(as.matrix(calibration.residuals[i,],nrow=1))
  #     
  #     KXX = kernelMatrix(kernel, X,X)
  #     KXY = kernelMatrix(kernel, X, Y)
  #     KYY = kernelMatrix(kernel,Y,Y)
  #     non.conformity.measure[i] =   mean(KXX) - 2*mean(KXY) + mean(KYY) 
  #   }
  #   return(list(ncm = non.conformity.measure, resids=calibration.residuals))
  # }
  # ################################################
  
  ##############################################
  # Now that we have a new data point, compute the non-conformity meaure
  assess.non.conformity<- function(point, calib.resid, kernel, subsample=1000){
    X = as.matrix(point)
    Y = as.matrix(calib.resid)
    #  Y = Y[sample(nrow(Y), subsample), ]
    
    KXX = kernelMatrix(kernel, X,X)
    KXY = kernelMatrix(kernel, X, Y)
    KYY = kernelMatrix(kernel,Y,Y)
    
    return(mean(KXX) - 2*mean(KXY) + mean(KYY))
  }
  # ###############################################
  # # Assess non-conformity in one dimension
  # assess.non.conformity.one.dim<- function(point, calib.resid, kernel, d){
  #   X = as.matrix(point[d])
  #   Y = as.matrix(calib.resid[,d])
  #   
  #   KXX = kernelMatrix(kernel, X,X)
  #   KXY = kernelMatrix(kernel, X, Y)
  #   KYY = kernelMatrix(kernel,Y,Y)
  #   
  #   return(mean(KXX) - 2*mean(KXY) + mean(KYY))
  # }
  # ##################################################
  
  # #################################################
  # #Initalise anomaly detection
  # init.anomaly.detection <- function() {
  #   return(list(p.value.smoothed= 0, in.anomalous.state=0))
  # }
  # ########################################
  
  #########################################
  #This is the main anomaly detection step
  do.anomaly.detection.step<- function(new.sensor.value, anom.struct, calibrated.residuals, calibrated.ncm, kernel){
    
    in.anomalous.state= anom.struct$in.anomalous.state
    p.value.smoothed = anom.struct$p.value.smoothed
    
    ncm = assess.non.conformity(new.sensor.value, calibrated.residuals, kernel)
    p.value <- (mean(calibrated.ncm < ncm))
    
    p.value.smoothed = (1-RUN.RULE.WEIGHT)*p.value + RUN.RULE.WEIGHT*p.value.smoothed
    
    cp.event = 0
    
    #go from non-anomaly state to anomaly state
    if ((in.anomalous.state == 0) & (p.value.smoothed > UPPER.THRESHOLD)){
      in.anomalous.state = 1
      cp.event = 1
    }
    
    #handling of grace period
    if  ((in.anomalous.state == 1) & (p.value.smoothed < UPPER.THRESHOLD)){
      in.anomalous.state = 0
      cp.event= 2
    }
    
    return(list(cp.event = cp.event, p.value.smoothed= p.value.smoothed, in.anomalous.state=in.anomalous.state))
  }
  ######################################
  
  #######################################
  # Get p value along a single sensor type to assess "root of cause"
  get.marginal.pvalue <-function(sensor.data, trained.models, calibration.struct, marginal.nnm) {
    pv = rep(0,4)
    for (d in range(1:4)){
      test.residual<- sensor.data[[paste0('Ch',d,'RMSVib')]]-predict(trained.models[[d]], sensor.data)
      test.ncm.d <- assess.non.conformity(test.residual, calibration.struct$resids[,d], rbf)
      pv[d] = mean(marginal.nnm[,d]<test.ncm.d)
    }
    
    return(pv)
  }
  #######################################
  
  ######################################
  #do the main test loop
  do.anom.test.loop <- function(sensor.data, anom.struct, testing.data, calibration.struct, kernel) {
    
    test.residuals <- t(do.call(rbind, lapply(1:4, FUN=function(i) sensor.data[[paste0('Ch',i,'RMSVib')]]-predict(trained.models[[i]], sensor.data))))
    anom.struct <- do.anomaly.detection.step(test.residuals,anom.struct, calibration.struct$resids, calibration.struct$ncm, kernel)
    
    return(list(anom.struct=anom.struct))
  }
  #####################################
  
  # #######################################
  # #This is just a piece of code which checks is my system in the right state, otherwise carry on
  # preprocess.and.check<-function(sensor.data){
  #   # BDB 03 - approved = ((sensor.data$HMMState==1) || (sensor.data$HMMState==2))
  #   approved = ((sensor.data$HMMState==1) || (sensor.data$HMMState==2) || (sensor.data$HMMState==3))
  #   # BDB 03 - approved = 1
  #   
  #   return(list(approved=approved, sensor.data=sensor.data))
  # }
  # ####################################
  
  # END OF FUNCTIONS
  #######################################
  
  #########################################
  # DATA FROM DATA MANAGER
  #######################################

  #read cmd data
  args <- commandArgs(trailingOnly = TRUE)
  uuid<-args[1]
  

  #take in command args and set them in order
  # BDB unixdatetime_array<-args[2]
  unixdatetime_array <- fromJSON(args[2])
  GMMState_array <- fromJSON(args[3])
  StationGenWatts_array <- fromJSON(args[4])
  Flow_array <- fromJSON(args[5])
  Speed_array <- fromJSON(args[6])
  FWInPress_array <- fromJSON(args[7])
  FWOutPress_array <- fromJSON(args[8])
  Ch1RMSVib_array <- fromJSON(args[9])
  Ch2RMSVib_array <- fromJSON(args[10])
  Ch3RMSVib_array <- fromJSON(args[11])
  Ch4RMSVib_array <- fromJSON(args[12])
  
  input_array_length = length(unixdatetime_array)
  datetime_array <- as.POSIXct(unixdatetime_array, origin="1970-01-01")

  #Create Data frame
  input.data <- data.frame(ds = datetime_array, 
                           HMMState = GMMState_array, 
                           StationGen = StationGenWatts_array,
                           Flow = Flow_array,
                           Speed = Speed_array,
                           FWInPress = FWInPress_array,
                           FWOutPress = FWOutPress_array,
                           Ch1RMSVib = Ch1RMSVib_array,
                           Ch2RMSVib = Ch2RMSVib_array,
                           Ch3RMSVib = Ch3RMSVib_array,
                           Ch4RMSVib = Ch4RMSVib_array,
                           stringsAsFactors = FALSE)
  
  #intermin_para_1 <- input.data$unixdatetime[1]
  intermin_para_1 <- input.data$unixdatetime
  intermin_para_2 <- as.integer(1)
  
  ###
  # ADD THE LAGS!!!
  vib.rms.cols.input.data <- grep("^Ch.*RMSVib$", colnames(input.data), value=TRUE)
  
  # for (col.name in vib.rms.cols.input.data) {
  #   input.data <- do.lags(input.data, col.name, 3)
  # }
  
  for (col.name in vib.rms.cols.input.data) {
    input.data <- MVCPP_do_lags(input.data, col.name, 3)
  }
  # ADD LAGS END
  ###
  
  ########################
  # Collate data code from Andrew D
  #Load the data
  #rul.data <- read.csv("rul_cov_test.csv", stringsAsFactors = FALSE)
  #rul.data$ds <-dmy_hms(rul.data$U2Time)
  #rul.data$HMMState = factor(rul.data$HMMState)
  
  #########################################
  # LOAD TRAINING AND CALIBRATION DATA FILE - Start
  
  #load(file = "MVCPP_Training_and_Calibration.Rdata")
  # temp remove bdb - load(file = "/opt/lumen/executable/MVCPP_Training_and_Calibration.RData")
  load(file = "/opt/lumen/executable/MVCPP_Training_and_Calibration.RData")
  # load(file = "/opt/lumen/executable/sensorandtrainedmodeldatasonly.RData")
  # load(file = "/opt/lumen/executable/sensorandtrainedmodeldatasonly.Rdata")
  
  # LOAD TRAINING AND CALIBRATION DATA FILE - End
  ##########################################
  
  ###########################
  ######################
  # Some Temporary Dummy Data
  dummy_numberic_array <- runif(1000, 1.0, 5.0)
  first_cell <- dummy_numberic_array[1]
  
  start_date <- dmy_hms("01-01-14 00:00:00")
  end_date <- dmy_hms("31-01-14 23:50:00")
  n_intervals <- interval(start_date,end_date)/minutes(10)
  dummy_ds_array <- start_date + minutes(0:n_intervals)
  
  dummy_HMMState_array <- rep(3, n_intervals+1)
  dummy_StationGen_array <- rep(650, n_intervals+1)
  dummy_Flow_array <- rep(480, n_intervals+1)
  dummy_Speed_array <- rep(5800, n_intervals+1)
  dummy_FWInPress_array <- rep(5800, n_intervals+1)
  dummy_FWOutPress_array <- rep(5800, n_intervals+1)
  dummy_Ch1RMSVib_array <- runif(n_intervals+1, 1.1, 1.3)
  dummy_Ch2RMSVib_array <- runif(n_intervals+1, 0.9, 1.1)
  dummy_Ch3RMSVib_array <- runif(n_intervals+1, 2.2, 2.4)
  dummy_Ch4RMSVib_array <- runif(n_intervals+1, 3.8, 4.0)
  
  testing.data.blair <- data.frame(dummy_ds_array,
                                   dummy_HMMState_array,
                                   dummy_StationGen_array, 
                                   dummy_Flow_array,
                                   dummy_Speed_array,
                                   dummy_FWInPress_array,
                                   dummy_FWOutPress_array,
                                   dummy_Ch1RMSVib_array,
                                   dummy_Ch2RMSVib_array,
                                   dummy_Ch3RMSVib_array,
                                   dummy_Ch4RMSVib_array,
                                   stringsAsFactors=FALSE)
  
  names(testing.data.blair)[names(testing.data.blair) == "dummy_ds_array"] <- "ds"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_HMMState_array"] <- "HMMState"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_StationGen_array"] <- "StationGen"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_Flow_array"] <- "Flow"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_Speed_array"] <- "Speed"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_FWInPress_array"] <- "FWInPress"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_FWOutPress_array"] <- "FWOutPress"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_Ch1RMSVib_array"] <- "Ch1RMSVib"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_Ch2RMSVib_array"] <- "Ch2RMSVib"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_Ch3RMSVib_array"] <- "Ch3RMSVib"
  names(testing.data.blair)[names(testing.data.blair) == "dummy_Ch4RMSVib_array"] <- "Ch4RMSVib"
  
  ###
  # ADD THE LAGS TO the DUMMY DATA!!!
  vib.rms.cols.blair <- grep("^Ch.*RMSVib$", colnames(testing.data.blair), value=TRUE)
  
  # for (col.name in vib.rms.cols.blair) {
  #   testing.data.blair <- do.lags(testing.data.blair, col.name, 3)
  # }
  
  for (col.name in vib.rms.cols.blair) {
    testing.data.blair <- MVCPP_do_lags(testing.data.blair, col.name, 3)
  }
  
  # ADD LAGS END
  ###
  
  ############ END OF DUMMY DATA ##############
  #############################################
  
  #################################################
  #### Create Change Point arrays/files - Start ###
  what_directory = getwd()
  JSON_File_Name_starts = "data_starts.json"
  JSON_File_Name_ends = "data_ends.json"
  JSON_File_Name_rocs = "data_rocs.json"
  JSON_File_Name_pvals = "data_pvals.json"
  JSON_File_Name_inanomstate = "data_inanomstate.json"
  
  CP_File_For_Use_starts <- file.path(what_directory, JSON_File_Name_starts)
  CP_File_For_Use_ends <- file.path(what_directory, JSON_File_Name_ends)
  CP_File_For_Use_rocs <- file.path(what_directory, JSON_File_Name_rocs)
  CP_File_For_Use_pvals <- file.path(what_directory, JSON_File_Name_pvals)
  CP_File_For_Use_inanomstate <- file.path(what_directory, JSON_File_Name_inanomstate)
  
  if (file.exists(CP_File_For_Use_starts)) {
    #isthereafile = 1
    changepoint.starts.data <- data.frame(starts = fromJSON(CP_File_For_Use_starts))
    changepoint.ends.data <- data.frame(ends = fromJSON(CP_File_For_Use_ends))
    
    rocs_array_1 <- data.frame(rocs=fromJSON(CP_File_For_Use_rocs))
    rocs_array_strs <- unite(rocs_array_1, rocs, remove=TRUE, sep=" ")
    length_rocs_array_strs = nrow(rocs_array_strs)
    intermin_list <- vector(mode="list", length=length_rocs_array_strs)
    for(i in 1:length_rocs_array_strs){
      int_1 = rocs_array_strs[i, "rocs"]
      int_2 = as.numeric(str_split(int_1," ")[[1]])
      intermin_list[[i]] = int_2
    }
    rocs_array_1 = intermin_list
    
    changepoint.pvals.data <- data.frame(pvals=fromJSON(CP_File_For_Use_pvals))
    changepoint.inanomstate.data <- data.frame(inanomstate=fromJSON(CP_File_For_Use_inanomstate))

  } else {
    starts_array_1 <- rep(0, input_array_length)
    ends_array_1 <- rep(0, input_array_length)
    
    rocs_pop_vals = c(0.0,0.0,0.0,0.0)
    rocs_array_1 <- vector(mode="list", length=input_array_length)
    for(i in 1:input_array_length)
    {
      # Adding vec to list
      rocs_array_1[[i]]<- rocs_pop_vals
    }
    
    p.vals_array <- rep(0, input_array_length)
    inanomstate_array <- rep(0, input_array_length)
    
    changepoint.starts.data <- data.frame(starts=starts_array_1)
    changepoint.ends.data <- data.frame(ends=ends_array_1)
    
    changepoint.pvals.data <- data.frame(pvals = p.vals_array)
    changepoint.inanomstate.data <- data.frame(inanomstate = inanomstate_array)

  }
  
  #### Create Change Point arrays/files - End ###
  ###############################################

  ####
  # Some test variables
  #entering_for_loop <- as.numeric(0)
  what_HMMState <- as.numeric(0)
  is_the_data_approved <- as.numeric(0)
  enter_rewrite_loop <- as.numeric(0)
  
  #############################################
  ##### ANALYTIC CODE - START ####
  
  #start anomaly detection
  last_p.values <- changepoint.pvals.data$pvals[[nrow(changepoint.pvals.data)]]
  last_inanomstate <- changepoint.inanomstate.data$inanomstate[[nrow(changepoint.inanomstate.data)]]
  
  anom.struct <- data.frame(p.value.smoothed=as.numeric(last_p.values),
                            in.anomalous.state=as.numeric(last_inanomstate),
                            stringsAsFactors=FALSE)
  # # BDB OLD - replaced 030221 - anom.struct <- init.anomaly.detection() # BDB !!!!!! HERE !!!!! 030221
  # 
  # # initialise changepoint lists #### 
  # cp.list.start = changepoint.starts.data$starts
  # cp.list.end = changepoint.ends.data$ends
  # cp.list.roc = rocs_array_1
  # 
  # # initialise p.values variable
  # #p.values <- rep(0, 1)
  # # last_p.values <- changepoint.pvals.data$pvals[[nrow(changepoint.pvals.data)]]
  # # last_inanomstate <- changepoint.inanomstate.data$inanomstate[[nrow(changepoint.inanomstate.data)]]
  # #p.values <- changepoint.data$pvalues
  # 
  # 
  # # Which set/row of inputs are we using
  # sensor.data <- testing.data.blair[dim(testing.data.blair)[1], ]
  sensor.data <- input.data[dim(input.data)[1], ]
   
  what_HMMState = sensor.data$HMMState # BDB

  preproc.struct= PreprocessAndCheck(sensor.data)

  is_the_data_approved = preproc.struct$approved # BDB
  
  test.array.transpose <- as.data.frame(t(sensor.data))
  
  n_cols_sensor_data <- ncol(sensor.data)

  
  ###################
  ####################
  # 
  if (preproc.struct$approved) {
  #
    entering_for_loop = as.integer(1)
  #
    sensor.data <- preproc.struct$sensor.data
    
    test.residuals <- t(do.call(rbind, lapply(1:4, FUN=function(i) sensor.data[[paste0('Ch',i,'RMSVib')]]-predict(trained.models[[i]], sensor.data))))

    # residuals_array <- array(numeric(),c(1,4))
    # for (i in 1:4){
    #   residuals_array[[i]] <- sensor.data[[paste0('Ch',i,'RMSVib')]]-predict(trained.models[[i]], sensor.data)
    # }
    # int.step.1 <- predict(trained.models[[1]], sensor.data)
    # #int.step.1 <- sensor.data[['ChRMSVib']]-predict(trained.models[[1]], sensor.data)
    # test_num <- int.step.1
  #   #is it anomalous?
  #   anom.query <- do.anom.test.loop(sensor.data, anom.struct, testing.data.blair, calibration.struct, rbf)
  #
  #   #extract a p-value (only for debugging)
  #   #OLDp.values[i] = anom.query$anom.struct$p.value.smoothed
  #   #p.values = anom.query$anom.struct$p.value.smoothed
  #   p.values_calc = anom.query$anom.struct$p.value.smoothed
  #
  #
  #     if (anom.query$anom.struct$cp.event==1) {
  #       #cp.list.start = c(cp.list.start, 1) # BDB - Add a true flag of the changepoint to the array 'list'
  #       # BDB 03 - cp.list.start_calc = as.integer(1)
  #       #Get root of cause  -- which sensor caused the anomaly
  #       # BDB 03 - roc.p.vals <- get.marginal.pvalue(sensor.data, trained.models, calibration.struct, marginal.nnm)
  #       # BDB 03 - cp.list.roc_calc = roc.p.vals
  #       #add root of cause values to list
  #       #cp.list.roc = c(cp.list.roc, list(roc.p.vals))
  #     } else if (anom.query$anom.struct$cp.event==2) {
  #       #cp.list.end = c(cp.list.end, 1) # BDB - Add a true flag of the changepoint to the array 'list'
  #       # BDB 03 - cp.list.end_calc = 1
  #     } else {
  #       # BDB 03 - cp.list.start_calc = as.integer(0)
  #       # BDB 03 - cp.list.roc_calc = c(0.0,0.0,0.0,0.0)
  #       # BDB 03 - cp.list.end_calc = 0
  #     }
  #
  #     anom.struct <- anom.query$anom.struct
  #
  }

  ########### BDB COMMENT OUT ####
  
  ############
  # BDB Start 040221
  
  #test.step <- predict(trained.models[[1]], sensor.data)
  
  # BDB End 040221
  ############
  
  
  ### BLAIR Array HOLD IN JSON FILES CODE ###
  
  cp.list.start_calc = as.integer(123)
  cp.list.end_calc = as.integer(321)
  cp.list.roc_calc = c(0.1,0.2,0.3,0.4)
  p.values_calc = as.numeric(0.567)
  inanomstate_calc = as.numeric(12)
  
  calcs_start_df <-data.frame(starts=cp.list.start_calc)
  calcs_end_df <-data.frame(ends=cp.list.end_calc)
  calcs_pvals_df <- data.frame(pvals = p.values_calc)
  calcs_inanomstate_df <- data.frame(inanomstate = inanomstate_calc)
  
  changepoint.starts.data <- rbind(changepoint.starts.data,calcs_start_df)
  changepoint.ends.data <- rbind(changepoint.ends.data,calcs_end_df)
  changepoint.pvals.data <- rbind(changepoint.pvals.data,calcs_pvals_df)
  changepoint.inanomstate.data <- rbind(changepoint.inanomstate.data,inanomstate_calc)
  
  changepoint.starts.data = changepoint.starts.data[2:nrow(changepoint.starts.data),]
  changepoint.ends.data = changepoint.ends.data[2:nrow(changepoint.ends.data),]
  changepoint.pvals.data = changepoint.pvals.data[2:nrow(changepoint.pvals.data),]
  changepoint.inanomstate.data = changepoint.inanomstate.data[2:nrow(changepoint.inanomstate.data),]
  
  rocs_array_1 = c(rocs_array_1, list(cp.list.roc_calc))
  rocs_array_1 = rocs_array_1[2:length(rocs_array_1)]

  write_json(changepoint.starts.data, CP_File_For_Use_starts)
  write_json(changepoint.ends.data, CP_File_For_Use_ends)
  write_json(rocs_array_1, CP_File_For_Use_rocs)
  write_json(changepoint.pvals.data, CP_File_For_Use_pvals)
  write_json(changepoint.inanomstate.data, CP_File_For_Use_inanomstate)
  
  ### BLAIR Array HOLD IN JSON FILES CODE ###
  ##########################
  
  
  
  ##### ANALYTIC CODE - END ####
  #############################################
  
  
  
  ###############################
  #execute code for analytic here
  
  # #MAIN Testing loop
  # testing.data <- rul.data.cleaned[(start.index+training.size+calibration.size):(start.index+training.size+calibration.size+testing.size),]
  # testing.data <-  testing.data[covariate.names]
  
  
  #############################
  # Store Result for Output Here
  
  # result.list<-list(Blair_R_Output_1_250121=calibration.data[1,2],
  #                   Blair_R_Output_2_250121=dummy_StationGen_array,
  #                   Blair_R_Output_2_string_error = intermin_para_1)
  
  # result.list<-list(Blair_R_Output_1_250121=calibration.data[1,2],
  #                   Blair_R_Output_2_250121=changepoint.starts.data,
  #                   Blair_R_Output_2_string_error = intermin_para_1)
  
  result.list<-list(MVCPP_CP_Starts_030221=changepoint.starts.data,
                    MVCPP_CP_Ends_030221=changepoint.ends.data,
                    MVCPP_CP_Rocs_030221 = changepoint.pvals.data,
                    Blair_Test_Integer = calibration.data[1,2],
                    Blair_Test_Integer_2 = sensor.data[1,2],
                    Blair_Test_Integer_3 = test.residuals[1],
                    Blair_Test_Integer_4 = n_cols_sensor_data)
  
  writeToRedis(uuid,result.list)
  
  
}, error=function(err){
  writeExceptionToRedis(args[1],err)})

