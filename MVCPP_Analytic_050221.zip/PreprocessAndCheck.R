PreprocessAndCheck<-function(sensor.data){
  # BDB 03 - approved = ((sensor.data$HMMState==1) || (sensor.data$HMMState==2))
  approved = ((sensor.data$HMMState==1) || (sensor.data$HMMState==2) || (sensor.data$HMMState==3))
  return(list(approved=approved, sensor.data=sensor.data))
}